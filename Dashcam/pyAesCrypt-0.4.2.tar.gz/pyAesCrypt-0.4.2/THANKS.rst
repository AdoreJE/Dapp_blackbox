Thanks
===============
* Thanks to `Ben Fisher`_ for providing a patch to improve decryption speed.

* Thanks to `Thomas O'Neill`_ for suggesting and implementing the password option in the script.

* Thanks to `Harish Navnit`_ for pointing out an issue about input and output files.

.. _Ben Fisher: https://downpoured.github.io/

.. _Thomas O'Neill: https://github.com/toneill818

.. _Harish Navnit: https://github.com/harishnavnit
